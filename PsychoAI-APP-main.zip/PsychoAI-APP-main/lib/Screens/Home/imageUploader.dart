import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:psychoai/common/db_functions.dart';
import 'package:sizer/sizer.dart';

class ImageUploadScreen extends StatefulWidget {
  @override
  _ImageUploadScreenState createState() => _ImageUploadScreenState();
}

class _ImageUploadScreenState extends State<ImageUploadScreen> {
  File? _image;
  final ImagePicker _picker = ImagePicker();
  String analyzedData = "";

  // Method to pick an image from the gallery
  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  // Method to send image to server (replace `url` with your server endpoint)
  Future<void> _sendImage() async {
    
    if (_image == null) return;

    DBFunctions.instance.updateUserInPoints(DBFunctions.instance.logedInUser, -30);

    String url = 'http://192.168.33.7:5000/upload'; // Replace with your server's IP and port
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.files.add(await http.MultipartFile.fromPath('image', _image!.path));
    request.fields['userid'] = 'khalil';
    
    try {
      var response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await http.Response.fromStream(response);
        print('Server response: ${responseData.body}');
        Map<String, dynamic> parsedData = jsonDecode(responseData.body);
        
        // Update the analyzedData and trigger a UI rebuild
        setState(() {
          analyzedData = parsedData["response"]["choices"][0]["message"]["content"];
        });
      } else {
        print('Image upload failed! error ${response.statusCode}');
      }
    } catch (e) {
      print('Error occurred while sending the image: $e');
    }
  }

  Future<void> _sendImageToOpenAI() async {
    if (_image == null) return;

    String url = 'https://api.openai.com/v1/images/analysis'; // Hypothetical endpoint for image analysis
    String apiKey = 'sk-r_eMbseYvngyCIpeW8-jyALJ_T5QhmDMSza4yaeuTET3BlbkFJgMaqjY3G4y8DUXxG8nPtJbN-c4yjAN04_xz6ymYFsA';
    var request = http.MultipartRequest('POST', Uri.parse(url));
    request.files.add(await http.MultipartFile.fromPath('image', _image!.path));
    request.headers['Authorization'] = 'Bearer $apiKey';

    try {
      var response = await request.send();
      if (response.statusCode == 200) {
        var responseData = await http.Response.fromStream(response);
        print('OpenAI response: ${responseData.body}');
        Map<String, dynamic> parsedData = jsonDecode(responseData.body);
        
        // Update the analyzedData and trigger a UI rebuild
        setState(() {
          analyzedData = parsedData["response"]["choices"][0]["message"]["content"];
        });
      } else {
        print('Image upload to OpenAI failed!');
        print(response);
      }
    } catch (e) {
      print('Error occurred while sending the image to OpenAI: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 3.h,),
            _image == null
                ?     InkWell(
                              onTap: (){
                                 showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      title: Text('Move to next page.'),
                                      content: Text('Change this to move to a page.'),
                                      actions: [
                                        ElevatedButton(
                                          onPressed: () {
                                            Navigator.of(context).pop(); // Close the dialog
                                          },
                                          child: Text('Exit'),
                                        ),
                                      ],
                                    );
                                  },
                                 );
                              },
                   child:  Container(
                              width: 90.w,
                              height: 25.h,
                     child: Stack(
                       children: [
                     
                         Container(
                              width: 90.w,
                              height: 25.h,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                image: DecorationImage(
                                  image:
                                      NetworkImage("https://via.placeholder.com/460x242"),
                                  fit: BoxFit.fill,
                                ),
                              ), 
                          ),
                        Container(
                           alignment: Alignment.center,
                          child: ElevatedButton(
                            onPressed: _pickImage,
                            child: Text('Pick Image from Gallery'),
                          ),
                        ),
                       ],
                     ),
                   ),
                )
                : Container(
                    width: 90.w,
                    height: 30.h,
                    child: Image.file(_image!),
                  ),
            
            ElevatedButton(
              onPressed: _sendImage,
              child: Text('Analyze Drawing'),
            ),
            SizedBox(height: 2.h,),
            Text("Analyzed Response from AI",style: TextStyle(fontSize: 6.w),),
            Container(
              width: 90.w,
              height: 25.h,
              decoration: BoxDecoration(border: Border.all(color: Colors.black),borderRadius: BorderRadius.circular(20)),
              padding: EdgeInsets.all(8.0),
              child: SingleChildScrollView(
                child: Text(
                  analyzedData,
                  style: TextStyle(fontSize: 14.sp),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
